package Seminar_03;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Random;

public class task_3 {

  public static void fillarray(ArrayList<Integer> array, int size) {
    Random random = new Random();
    for (int i = 0; i < size; i++) {
      array.add(random.nextInt(99));
    }
  }

  public static void printarray(ArrayList<Integer> array) {
    Iterator<Integer> itar = array.iterator();
    while (itar.hasNext()) {
      System.out.print(itar.next() + " ");
    }
  }

  public static int averageList(ArrayList<Integer> array) {
    int sum = 0;
    int len = array.size();
    for (int i = 0; i < len; i++) {
      sum += array.get(i);
    }
    return sum /= len;
  }

  public static void main(String[] args) {
    // Задан целочисленный список ArrayList. Найти минимальное, максимальное и
    // среднее из этого списка.
    int size = 20;
    System.out.println("\nЗ А Д А Ч А  3\n");
    ArrayList<Integer> array = new ArrayList<>();

    fillarray(array, size);
    System.out.print("Массив заполнен - - ----------> ");
    printarray(array);
    System.out.print("\nМинимальное число в массиве --> ");
    int min = Collections.min(array);
    System.out.print(min);
    System.out.print("\nМаксимальное число в массиве -> ");
    int max = Collections.max(array);
    System.out.print(max);
    System.out.print("\nСреднее число в массиве - - --> ");
    int av = averageList(array);
    System.out.print(av);
    System.out.print("\n\n");

  }
}
