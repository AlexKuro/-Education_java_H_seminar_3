package Seminar_03;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class task_2 {

  public static void fillarray(ArrayList<Integer> array, int size) {
    Random random = new Random();
    for (int i = 0; i < size; i++) {
      array.add(random.nextInt(99));
    }
  }

  public static void printarray(ArrayList<Integer> array) {
    Iterator<Integer> itar = array.iterator();
    while (itar.hasNext()) {
      System.out.print(itar.next() + " ");
    }
  }

  public static void main(String[] args) {
    // Пусть дан произвольный список целых чисел, удалить из него чётные числа
    int size = 21;
    System.out.println("\nЗ А Д А Ч А  2\n");
    ArrayList<Integer> array = new ArrayList<>();

    fillarray(array, size);
    System.out.print("Массив заполнен - - - ---> ");
    printarray(array);
    System.out.print("\nМассив без четных чисел -> ");
    array.removeIf(n -> (n % 2 == 0));
    printarray(array);
    System.out.print("\n\n");

  }
}
