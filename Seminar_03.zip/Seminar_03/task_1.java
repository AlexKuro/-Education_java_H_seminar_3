package Seminar_03;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class task_1 {

  public static void fillarray(ArrayList<Integer> array, int size) {
    Random random = new Random();
    for (int i = 0; i < size; i++) {
      array.add(random.nextInt(99));
    }
  }

  public static void printarray(ArrayList<Integer> array) {
    Iterator<Integer> itar = array.iterator();
    while (itar.hasNext()) {
      System.out.print(itar.next() + " ");
    }
  }

  private static void merge(ArrayList<Integer> array,
      ArrayList<Integer> left, ArrayList<Integer> right,
      int sizeL, int sizeR) {
    int i = 0, j = 0, k = 0;
    while (i < sizeL && j < sizeR) {
      if (left.get(i) <= right.get(j)) {
        array.set(k++, left.get(i++));
      } else {
        array.set(k++, right.get(j++));
      }
    }

    while (i < sizeL) {
      array.set(k++, left.get(i++));
    }
    while (j < sizeR) {
      array.set(k++, right.get(j++));
    }

  }

  public static void mergeSort(ArrayList<Integer> array, int size) {

    if (size < 2) {
      return;
    }
    int half = size / 2;

    ArrayList<Integer> left = new ArrayList<>(array.subList(0, half));
    ArrayList<Integer> right = new ArrayList<>(array.subList(half, size));

    mergeSort(left, half);
    mergeSort(right, size - half);

    merge(array, left, right, half, size - half);
  }

  public static void main(String[] args) {
    // task_1 - Реализовать алгоритм сортировки слиянием
    int size = 12;
    System.out.println("\nЗ А Д А Ч А  1\n");
    System.out.println("- -- Cортировка слиянием -- -");
    ArrayList<Integer> array = new ArrayList<>();
    fillarray(array, size);
    System.out.print("Массив заполнен - - ----> ");
    printarray(array);
    System.out.print("\nОтсортированный массив -> ");
    mergeSort(array, size);
    printarray(array);
    System.out.print("\n\n");

  }
}